from django.urls import path

from api import views


app_name = 'api'
urlpatterns = [
    path('post/<int:pk>/like/', views.ApiPostLikeDV.as_view(), name='api-post-like'),
]
