from django.http import JsonResponse
from django.views.generic.detail import BaseDetailView

from blog.models import Post


class ApiPostLikeDV(BaseDetailView):
    model = Post

    def render_to_response(self, context, **response_kwargs):
        obj = context['object']
        obj.like += 1
        obj.save()
        return JsonResponse(data=obj.like, safe=False, status=200)
