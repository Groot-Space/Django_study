from django.views.generic import TemplateView


class PostDV(TemplateView):
    template_name = 'blog/post_detail.html'
