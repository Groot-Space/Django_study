from django.views.generic import TemplateView, DetailView

from blog.models import Post


# class PostDV(TemplateView):
#     template_name = 'blog/post_detail.html'


class PostDV(DetailView):
    model = Post
    template_name = 'blog/post_detail.html'
