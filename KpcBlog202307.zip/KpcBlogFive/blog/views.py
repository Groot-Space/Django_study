from django.views.generic import TemplateView, DetailView

from blog.models import Post


# class PostDV(TemplateView):
#     template_name = 'blog/post_detail.html'


class PostDV(DetailView):
    model = Post
    template_name = 'blog/post_detail.html'


class PostLikeDV(DetailView):
    model = Post
    template_name = 'blog/post_detail.html'

    def get(self, request, *args, **kwargs):
        self.object = self.get_object()
        self.object.like += 1
        self.object.save()
        context = self.get_context_data(object=self.object)
        return self.render_to_response(context)
