from django.views.generic import TemplateView, ListView

from blog.models import Post


# class HomeView(TemplateView):
#     template_name = 'home.html'


class HomeView(ListView):
    model = Post
    template_name = 'home.html'
