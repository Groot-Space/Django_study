const calculator = document.querySelector('.calculator');
const buttons = calculator.querySelector('.calculator__buttons');
const firstOperend = document.querySelector('.calculator__operend--left');
const operator = document.querySelector('.calculator__operator');
const secondOperend = document.querySelector('.calculator__operend--right');
const calculatedResult = document.querySelector('.calculator__result');

function calculate(n1, operator, n2) {
  let result = 0;
  if(operator === '+') {
    result = Number(n1) + Number(n2);
  }
  else if(operator === '-') {
     result = Number(n1) - Number(n2);
  }
  else if(operator === '*') {
     result = Number(n1) * Number(n2);
  }
  else {
     result = Number(n1) / Number(n2);
  }
  return String(result);
}

let firstChange = false;
buttons.addEventListener('click', function (event) {
  const target = event.target; // 클릭된 HTML 엘리먼트의 정보가 저장되어 있습니다.
  const action = target.classList[0]; // 클릭된 HTML 엘리먼트에 클레스 정보를 가져옵니다.
  const buttonContent = target.textContent; // 클릭된 HTML 엘리먼트의 텍스트 정보를 가져옵니다.
  if (target.matches('button')) {
    if (action === 'number') {
      if (firstChange === false){
        firstOperend.textContent = buttonContent;
        firstChange = true;
      } else {
        secondOperend.textContent = buttonContent;
      }
      console.log(buttonContent);
    }
    if (action === 'operator') {
      operator.textContent = buttonContent;
      console.log(buttonContent);
    }
    if (action === 'decimal') {
      console.log('소수점');
    }
    if (action === 'clear') {
      firstOperend.textContent = 0;
      operator.textContent = "+";
      secondOperend.textContent = 0;
      calculatedResult.textContent = 0;
      firstChange = false;
      console.log('초기화');
    }
    if (action === 'calculate') {
      calculatedResult.textContent = calculate(firstOperend.textContent,operator.textContent,secondOperend.textContent);
      console.log(calculatedResult.textContent);
    }
  }
});
