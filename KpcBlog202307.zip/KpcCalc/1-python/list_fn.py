"""
1. list reference
2. reserved word (max)
"""
def list_max(alist):
    alist.sort()
    return alist[-1]


lst = [9, 7, 5, 3, 1]
result = list_max(lst)

print(f"{result=}")
print(f"{lst=}")
