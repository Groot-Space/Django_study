"""
a. normal argument
b=10. default argument
*args. variable argument, 가변인자, tuple 로 변환됨
**kwargs. variable argument, 가변인자, dict 로 변환됨
"""


def func(a, b=10, *args, **kwargs):
    print("============================ func")
    print("a =", a)
    print("b =", b)
    print("args =", args)
    print("kwargs =", kwargs)


if __name__ == '__main__':
    func(10, 20, 30, 40, kk=50)
