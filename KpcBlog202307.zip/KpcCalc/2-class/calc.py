
class Calculator:
    brand = 'sony'

    def __init__(self, name):
        self.name = name

    def calculte(self, a, b):
        hap = self.add(a, b)
        dif = self.subtract(a, b)
        result = {
            'hap': hap,
            'dif': dif,
        }
        return result

    def add(self, a, b):
        return a + b

    def subtract(self, a, b):
        return a - b

    def info(self):
        result = {
            'brand': self.brand,
            'name': self.name,
        }
        return result
