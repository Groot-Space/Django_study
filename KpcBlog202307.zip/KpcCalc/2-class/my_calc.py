from calc import Calculator


class MyCalculator(Calculator):
    def calculte(self, a, b):
        res = super().calculte(a, b)
        res['multi'] = a * b
        return res
