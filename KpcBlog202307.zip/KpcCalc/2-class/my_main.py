from calc import Calculator
from my_calc import MyCalculator


calc1 = Calculator(name='simple')
res1 = calc1.calculte(3, 5)
print(f"{res1=}")

info1 = calc1.info()
print(f"{info1=}")

print()

# ------------------------------------
calc2 = MyCalculator(name='complex')
res2 = calc2.calculte(3, 5)
print(f"{res2=}")

calc2.brand = 'samsung'

info2 = calc2.info()
print(f"{info2=}")
